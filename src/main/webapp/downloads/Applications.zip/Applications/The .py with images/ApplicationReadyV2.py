import tkinter as tk
from tkinter import Text, Label, Button, Entry, Radiobutton, OptionMenu, StringVar, BooleanVar, PhotoImage
from PIL import Image
import string
import random
import numpy as np
import threading

def caesar_cipher(text, shift, direction):
    if direction == 'dec':
        shift = -shift
    result = ""
    for char in text:
        if char.isalpha():
            shift_amount = shift % 26
            start = ord('a') if char.islower() else ord('A')
            shifted = (ord(char) - start + shift_amount) % 26
            result += chr(start + shifted)
        else:
            result += char
    return result

def create_playfair_matrix(keyword):
    matrix = []
    seen = set()
    keyword = keyword.replace(" ", "").upper()
    for char in keyword:
        if char not in seen and char != 'J':
            seen.add(char)
            matrix.append(char)
    alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"
    for char in alphabet:
        if char not in seen and char != 'J':
            matrix.append(char)
    return matrix

def playfair_encrypt_decrypt(message, matrix, encrypt=True):
    def chunker(seq, size):
        return (seq[pos:pos + size] for pos in range(0, len(seq), size))

    def find_position(letter):
        index = matrix.index(letter)
        return index // 5, index % 5

    message = message.replace("J", "I").upper()
    if not encrypt:
        message = message.replace("X", "")
    output = ""
    for char1, char2 in chunker(message, 2):
        if char1 == char2:
            char2 = 'X'
        row1, col1 = find_position(char1)
        row2, col2 = find_position(char2)
        if row1 == row2:
            if encrypt:
                col1 = (col1 + 1) % 5
                col2 = (col2 + 1) % 5
            else:
                col1 = (col1 - 1) % 5
                col2 = (col2 - 1) % 5
        elif col1 == col2:
            if encrypt:
                row1 = (row1 + 1) % 5
                row2 = (row2 + 1) % 5
            else:
                row1 = (row1 - 1) % 5
                row2 = (row2 - 1) % 5
        else:
            col1, col2 = col2, col1
        output += matrix[row1 * 5 + col1] + matrix[row2 * 5 + col2]
    return output

def encrypt_vigenere(plain_text, key):
    key = key.upper()
    key_length = len(key)
    encrypted_text = ''
    for i, char in enumerate(plain_text):
        if char.isalpha():
            shift = ord(key[i % key_length]) - 65
            encrypted_text += caesar_cipher(char, shift, 'enc' if char.islower() else 'ENC')
        else:
            encrypted_text += char
    return encrypted_text

def decrypt_vigenere(cipher_text, key):
    key = key.upper()
    key_length = len(key)
    decrypted_text = ''
    for i, char in enumerate(cipher_text):
        if char.isalpha():
            shift = ord(key[i % key_length]) - 65
            decrypted_text += caesar_cipher(char, shift, 'dec' if char.islower() else 'DEC')
        else:
            decrypted_text += char
    return decrypted_text

def encrypt_rail_fence(text, num_rails):
    text = text.replace(" ", "").upper()
    rails = [''] * num_rails
    direction = 1
    rail = 0
    for char in text:
        rails[rail] += char
        if rail == 0:
            direction = 1
        elif rail == num_rails - 1:
            direction = -1
        rail += direction
    return ''.join(rails)

def decrypt_rail_fence(ciphertext, num_rails):
    pattern = get_pattern(len(ciphertext), num_rails)
    rails = ['' for _ in range(num_rails)]
    rail_len = [pattern.count(r) for r in range(num_rails)]
    index = 0
    for i, rlen in enumerate(rail_len):
        rails[i] = ciphertext[index:index+rlen]
        index += rlen
    plaintext = ''
    rail = 0
    direction = 1
    for _ in range(len(ciphertext)):
        plaintext += rails[rail][0]
        rails[rail] = rails[rail][1:]
        rail += direction
        if rail == 0 or rail == num_rails - 1:
            direction *= -1
    return plaintext

def get_pattern(length, num_rails):
    pattern = []
    rail = 0
    direction = 1
    for _ in range(length):
        pattern.append(rail)
        rail += direction
        if rail == 0 or rail == num_rails - 1:
            direction *= -1
    return pattern

def generate_password(length=8, use_digits=True, use_uppercase=True, use_lowercase=True, use_special_symbols=True):
    characters = ''
    if use_lowercase:
        characters += string.ascii_lowercase
    if use_digits:
        characters += string.digits
    if use_uppercase:
        characters += string.ascii_uppercase
    if use_special_symbols:
        characters += string.punctuation

    if not characters:
        raise ValueError("At least one character type must be selected!")

    password = ''.join(random.choice(characters) for _ in range(length))
    return password

def hill_cipher_encrypt(plain_text, key_matrix):
    n = len(key_matrix)
    plain_text = plain_text.upper().replace(" ", "")
    
    # Pad the plaintext if its length is not divisible by the size of the key matrix
    remainder = len(plain_text) % n
    if remainder != 0:
        plain_text += 'X' * (n - remainder)  # Padding with 'X' if not a multiple of n

    result = ""
    for i in range(0, len(plain_text), n):
        block = [ord(char) - 65 for char in plain_text[i:i + n]]
        block = np.dot(key_matrix, np.array(block).reshape(-1, 1)) % 26
        result += ''.join(chr(char + 65) for char in block.flatten())
    return result

def mod_inv(a, m):
    """ Compute the modular inverse of a under modulus m """
    a = a % m
    for x in range(1, m):
        if (a * x) % m == 1:
            return x
    return None  # If no modular inverse exists

def hill_cipher_decrypt(cipher_text, key_matrix):
    n = len(key_matrix)
    if len(cipher_text) % n != 0:
        raise ValueError("Cipher text length must be a multiple of the key matrix size.")

    determinant = int(np.round(np.linalg.det(key_matrix)))
    det_inv = mod_inv(determinant, 26)

    if det_inv is None:
        raise ValueError("The key matrix is not invertible under modulo 26.")

    adjugate = np.round(det_inv * np.linalg.inv(key_matrix) * determinant).astype(int) % 26
    key_matrix_inv = adjugate % 26

    cipher_numerical = [(ord(char) - 65) for char in cipher_text]
    cipher_matrix = np.array(cipher_numerical).reshape(-1, n)

    decrypted_numerical = np.dot(cipher_matrix, key_matrix_inv) % 26
    decrypted_text = ''.join(chr(int(num) + 65) for num in decrypted_numerical.flatten())

    return decrypted_text

# Example usage
key_matrix = np.array([[6, 5], [3, 4]])
cipher_text = "ENCRYPTEDMESSAGE"
try:
    decrypted_message = hill_cipher_decrypt(cipher_text, key_matrix)
    print("Decrypted message:", decrypted_message)
except ValueError as e:
    print(str(e))

current_frame = None

def destroy_current_frame():
    global current_frame
    if current_frame:
        current_frame.destroy()

def open_caesar_cipher_gui():
    global current_frame
    destroy_current_frame()
    current_frame = tk.Frame(root, bg='black')
    current_frame.pack()

    tk.Label(current_frame, text="Direction ('enc' or 'dec'):", bg='black', fg='white').grid(row=0, column=0)
    direction_var = tk.StringVar(current_frame)
    direction_var.set("enc")  
    tk.OptionMenu(current_frame, direction_var, "enc", "dec").grid(row=0, column=1)

    tk.Label(current_frame, text="Shift Amount:", bg='black', fg='white').grid(row=1, column=0)
    shift_var = tk.StringVar(current_frame)
    tk.Entry(current_frame, textvariable=shift_var).grid(row=1, column=1)

    tk.Label(current_frame, text="Message:", bg='black', fg='white').grid(row=2, column=0)
    message_var = tk.StringVar(current_frame)
    tk.Entry(current_frame, textvariable=message_var).grid(row=2, column=1)

    result_label = tk.Label(current_frame, text="", bg='black', fg='white')
    result_label.grid(row=4, columnspan=2)

    def process_message():
        direction = direction_var.get()
        try:
            shift = int(shift_var.get())
        except ValueError:
            result_label.config(text="Error: Shift amount must be an integer.")
            return

        message = message_var.get()
        processed_message = caesar_cipher(message, shift, direction)
        result_label.config(text="Processed Message: " + processed_message)

    process_button = tk.Button(current_frame, text="Process Message", command=process_message, bg='red', fg='white')
    process_button.grid(row=3, columnspan=2)

def open_playfair_cipher_gui():
    global current_frame
    destroy_current_frame()
    current_frame = tk.Frame(root, bg='black')
    current_frame.pack()

    tk.Label(current_frame, text="Direction ('enc' for encrypt, 'dec' for decrypt):", bg='black', fg='white').grid(row=0, column=0)
    direction_var = tk.StringVar(current_frame)
    direction_var.set("enc")  # default value
    tk.OptionMenu(current_frame, direction_var, "enc", "dec").grid(row=0, column=1)

    tk.Label(current_frame, text="Keyword (letters only):", bg='black', fg='white').grid(row=1, column=0)
    keyword_var = tk.StringVar(current_frame)
    tk.Entry(current_frame, textvariable=keyword_var).grid(row=1, column=1)

    tk.Label(current_frame, text="Message:", bg='black', fg='white').grid(row=2, column=0)
    message_var = tk.StringVar(current_frame)
    tk.Entry(current_frame, textvariable=message_var).grid(row=2, column=1)

    result_label = tk.Label(current_frame, text="", bg='black', fg='white')
    result_label.grid(row=4, columnspan=2)

    def process_message():
        direction = direction_var.get()
        keyword = keyword_var.get()
        message = message_var.get()
        if keyword.isalpha():
            matrix = create_playfair_matrix(keyword)
            processed_message = playfair_encrypt_decrypt(message, matrix, encrypt=(direction == 'enc'))
            result_label.config(text="Processed Message: " + processed_message)
        else:
            result_label.config(text="Error: Keyword must contain letters only.")

    process_button = tk.Button(current_frame, text="Process Message", command=process_message, bg='red', fg='white')
    process_button.grid(row=3, columnspan=2)

def open_vigenere_cipher_gui():
    global current_frame
    destroy_current_frame()
    current_frame = tk.Frame(root, bg='black')
    current_frame.pack()

    tk.Label(current_frame, text="Direction ('enc' for encrypt, 'dec' for decrypt):", bg='black', fg='white').grid(row=0, column=0)
    direction_var = tk.StringVar(current_frame)
    direction_var.set("enc")  # default value
    tk.OptionMenu(current_frame, direction_var, "enc", "dec").grid(row=0, column=1)

    tk.Label(current_frame, text="Keyword (letters only):", bg='black', fg='white').grid(row=1, column=0)
    keyword_var = tk.StringVar(current_frame)
    tk.Entry(current_frame, textvariable=keyword_var).grid(row=1, column=1)

    tk.Label(current_frame, text="Message:", bg='black', fg='white').grid(row=2, column=0)
    message_var = tk.StringVar(current_frame)
    tk.Entry(current_frame, textvariable=message_var).grid(row=2, column=1)

    result_label = tk.Label(current_frame, text="", bg='black', fg='white')
    result_label.grid(row=4, columnspan=2)

    def process_message():
        direction = direction_var.get()
        keyword = keyword_var.get()
        message = message_var.get()
        if keyword.isalpha():
            if direction == 'enc':
                processed_message = encrypt_vigenere(message, keyword)
            else:
                processed_message = decrypt_vigenere(message, keyword)
            result_label.config(text="Processed Message: " + processed_message)
        else:
            result_label.config(text="Error: Keyword must contain letters only.")

    process_button = tk.Button(current_frame, text="Process Message", command=process_message, bg='red', fg='white')
    process_button.grid(row=3, columnspan=2)

def open_rail_fence_cipher_gui():
    global current_frame
    destroy_current_frame()
    current_frame = tk.Frame(root, bg='black')
    current_frame.pack()

    action_var = tk.StringVar(value='enc')

    tk.Radiobutton(current_frame, text="Encrypt", variable=action_var, value='enc', bg='black', fg='white', selectcolor="black").grid(row=0, column=0, padx=10, pady=10)
    tk.Radiobutton(current_frame, text="Decrypt", variable=action_var, value='dec', bg='black', fg='white', selectcolor="black").grid(row=0, column=1, padx=10, pady=10)

    tk.Label(current_frame, text="Number of Rails:", bg='black', fg='white').grid(row=1, column=0, padx=10, pady=10)
    num_rails_entry = tk.Entry(current_frame, bg="white", fg='black')
    num_rails_entry.grid(row=1, column=1, padx=10, pady=10)

    tk.Label(current_frame, text="Text:", bg='black', fg='white').grid(row=2, column=0, padx=10, pady=10)
    text_entry = Text(current_frame, height=4, width=50, bg="white", fg='black')
    text_entry.grid(row=2, column=1, padx=10, pady=10)

    result_label = tk.Label(current_frame, text="", bg='black', fg='white')
    result_label.grid(row=4, column=0, columnspan=2)

    def perform_action():
        num_rails = int(num_rails_entry.get())
        text = text_entry.get("1.0", "end-1c")
        if action_var.get() == 'enc':
            result = encrypt_rail_fence(text, num_rails)
        else:
            result = decrypt_rail_fence(text, num_rails)
        result_label.config(text="Result: " + result)

    action_button = tk.Button(current_frame, text="Run", command=perform_action, bg='red', fg='white')
    action_button.grid(row=3, column=0, columnspan=2, padx=10, pady=10)

def is_invertible(matrix):
    """
    Check if a square matrix is invertible.
    
    Parameters:
        matrix (numpy.ndarray): The square matrix to check.
        
    Returns:
        bool: True if the matrix is invertible, False otherwise.
    """
    # Check if the matrix is square
    if matrix.shape[0] != matrix.shape[1]:
        raise ValueError("Matrix must be square to be invertible.")
    
    # Calculate the determinant of the matrix
    determinant = np.linalg.det(matrix)
    
    # Check if the determinant is non-zero
    return determinant != 0

def open_hill_cipher_gui():
    global current_frame
    destroy_current_frame()
    current_frame = tk.Frame(root, bg='black')
    current_frame.pack()

    # Choice for encryption or decryption
    mode_var = tk.StringVar(value='enc')
    tk.Radiobutton(current_frame, text="Encrypt", variable=mode_var, value='enc', bg='black', fg='white', selectcolor="black").grid(row=0, column=0)
    tk.Radiobutton(current_frame, text="Decrypt", variable=mode_var, value='dec', bg='black', fg='white', selectcolor="black").grid(row=0, column=1)

    tk.Label(current_frame, text="Key Matrix (semicolon-separated rows, comma-separated values):", bg='black', fg='white').grid(row=1, column=0)
    key_var = tk.StringVar(current_frame)
    tk.Entry(current_frame, textvariable=key_var).grid(row=1, column=1)

    tk.Label(current_frame, text="Message:", bg='black', fg='white').grid(row=2, column=0)
    message_var = tk.StringVar(current_frame)
    tk.Entry(current_frame, textvariable=message_var).grid(row=2, column=1)

    result_label = tk.Label(current_frame, text="", bg='black', fg='white')
    result_label.grid(row=4, columnspan=2)

    def process_message():
        mode = mode_var.get()
        key_str = key_var.get()
        message = message_var.get()

        try:
            key_matrix = np.array([[int(num) for num in part.split(',')] for part in key_str.split(';')])
        except ValueError:
            result_label.config(text="Error: Invalid key matrix format.")
            return

        if not is_invertible(key_matrix):
            result_label.config(text="Error: Key matrix is not invertible.")
            return

        if any(not char.isalpha() for char in message.replace(" ", "")):  # Allow spaces in input but ignore them in processing
            result_label.config(text="Error: Message must contain only alphabetic characters.")
            return

        if mode == 'enc':
            processed_message = hill_cipher_encrypt(message.replace(" ", "").upper(), key_matrix)
        else:
            processed_message = hill_cipher_decrypt(message.replace(" ", "").upper(), key_matrix)

        result_label.config(text="Processed Message: " + processed_message)

    process_button = tk.Button(current_frame, text="Process Message", command=process_message, bg='red', fg='white')
    process_button.grid(row=3, columnspan=2)
def open_password_generator_gui():
    global current_frame
    destroy_current_frame()
    current_frame = tk.Frame(root, bg='black')
    current_frame.pack()

    length_label = tk.Label(current_frame, text="Password Length:", bg='black', fg='white')
    length_label.pack(pady=(20, 10))
    length_entry = tk.Entry(current_frame, bg="white", fg='black')
    length_entry.pack()

    digits_var = tk.BooleanVar(value=True)
    uppercase_var = tk.BooleanVar(value=True)
    lowercase_var = tk.BooleanVar(value=True)
    symbols_var = tk.BooleanVar(value=True)

    # Correctly using BooleanVar for Checkbutton
    tk.Checkbutton(current_frame, text="Include Digits", variable=digits_var, onvalue=True, offvalue=False, bg='black', fg='white', selectcolor="black").pack()
    tk.Checkbutton(current_frame, text="Include Uppercase Letters", variable=uppercase_var, onvalue=True, offvalue=False, bg='black', fg='white', selectcolor="black").pack()
    tk.Checkbutton(current_frame, text="Include Lowercase Letters", variable=lowercase_var, onvalue=True, offvalue=False, bg='black', fg='white', selectcolor="black").pack()
    tk.Checkbutton(current_frame, text="Include Symbols", variable=symbols_var, onvalue=True, offvalue=False, bg='black', fg='white', selectcolor="black").pack()

    result_label = tk.Label(current_frame, text="", bg='black', fg='white')
    result_label.pack(pady=(10, 0))


    def create_password():
        length = int(length_entry.get())
        use_digits = digits_var.get()
        use_uppercase = uppercase_var.get()
        use_lowercase = lowercase_var.get()
        use_special_symbols = symbols_var.get()

        password = generate_password(length, use_digits, use_uppercase, use_lowercase, use_special_symbols)
        result_label.config(text="Generated Password: " + password)

    generate_button = tk.Button(current_frame, text="Generate Password", command=create_password, bg='red', fg='white')
    generate_button.pack(pady=20)

def set_icon(window, icon_path):
    img = Image.open(icon_path)
    img.save('app_icon.ico', format='ICO', sizes=[(32, 32)])  # Convert and save as ICO
    window.iconbitmap('app_icon.ico')

# Define the path to your image
background_image_path = "./bg-img.png"

# Function to set the background image of a tkinter window
def set_background_image(window, image_path):
    background_image = PhotoImage(file=image_path)
    background_label = tk.Label(window, image=background_image)
    background_label.image = background_image  # Keep a reference to the image to prevent it from being garbage collected
    background_label.place(relwidth=1, relheight=1)

# Main application window setup
root = tk.Tk()
root.title("Cryptography Toolkit")
root.configure(bg='black')

# Call this function in your main window setup
set_background_image(root, background_image_path)

# Disable window resizing (maximizing)
root.resizable(False, False)

# Set the window icon (ensure the path to your image is correct)
set_icon(root, "./Hacker 2.png")

# Your UI setup code here
welcome_label = tk.Label(root, text="Welcome to the Cryptography Toolkit!", bg='black', fg='red', font=('Arial', 16, 'bold'))
welcome_label.pack(padx=20, pady=20)

# More UI components can be added here

# Button arrangement
ciphers = [
    ("Caesar Cipher", open_caesar_cipher_gui),
    ("Playfair Cipher", open_playfair_cipher_gui),
    ("Rail Fence Cipher", open_rail_fence_cipher_gui),
    ("Vigenère Cipher", open_vigenere_cipher_gui),
    ("Hill Cipher", open_hill_cipher_gui),
    ("Password Generator", open_password_generator_gui)
]

left_frame = tk.Frame(root, bg='black')
left_frame.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.Y)

right_frame = tk.Frame(root, bg='black')
right_frame.pack(side=tk.RIGHT, padx=10, pady=10, fill=tk.Y)

for i, (cipher_name, function) in enumerate(ciphers):
    frame = left_frame if i < len(ciphers) // 2 else right_frame
    Button(frame, text=cipher_name, command=function, bg='red', fg='white').pack(pady=5, padx=10, fill=tk.X)

root.mainloop()

# Welcome Window Setup

welcome_window = tk.Tk()
welcome_window.title("Welcome")
welcome_window.configure(bg='black')

welcome_label = Label(welcome_window, text="Welcome to the Cryptography Toolkit!", bg='black', fg='red', font=('Arial', 16, 'bold'))
welcome_label.pack(padx=20, pady=20)

welcome_button = Button(welcome_window, text="Enter", command=open_main_window, bg='red', fg='white', font=('Arial', 14))
welcome_button.pack(pady=20)

welcome_window.mainloop()
